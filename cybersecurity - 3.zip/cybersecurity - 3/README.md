# 🛡️ Web Application Penetration Testing using OWASP ZAP

## 📌 Project Overview

This project demonstrates the process of performing web application penetration testing using **OWASP ZAP (Zed Attack Proxy)** on the **OWASP Juice Shop** application running locally via Docker.

The objective was to identify common web application security vulnerabilities through automated scanning and basic manual testing while following ethical hacking practices.

---

## 🎯 Objectives

- Perform web application security assessment using OWASP ZAP.
- Discover web pages and application endpoints.
- Identify security vulnerabilities through passive and active scanning.
- Understand the OWASP Top 10 security risks.
- Generate a professional penetration testing report.

---

## 🛠️ Tools & Technologies

- OWASP ZAP v2.17.0
- OWASP Juice Shop
- Docker Desktop
- macOS (Apple Silicon M4)
- Google Chrome / Brave Browser

---

## 📂 Project Structure

```
Web-Application-Penetration-Testing/
│
├── README.md
├── report.pdf
├── zap-report.html
├── screenshots/
│   ├── juice-shop-homepage.png
│   ├── zap-scan.png
│   ├── alerts.png
│   ├── sites-tree.png
│   └── report-generation.png
└── assets/
```

---

# 🚀 Environment Setup

### 1. Install Docker Desktop

Download and install Docker Desktop for macOS.

### 2. Pull OWASP Juice Shop

```bash
docker pull bkimminich/juice-shop
```

### 3. Run Juice Shop

```bash
docker run -d -p 3000:3000 --name juice-shop bkimminich/juice-shop
```

### 4. Open the Application

```
http://localhost:3000
```

---

# 🔍 Penetration Testing Process

### Step 1

Launch OWASP ZAP.

### Step 2

Navigate to:

```
Quick Start → Automated Scan
```

### Step 3

Enter the target URL:

```
http://localhost:3000
```

### Step 4

Click **Attack**.

### Step 5

Allow OWASP ZAP to perform:

- Traditional Spider
- Passive Scan
- Active Scan

### Step 6

Review the discovered URLs and generated alerts.

### Step 7

Generate the HTML report from:

```
Report → Generate Report
```

---

# 🧪 Manual Testing

## SQL Injection

### Payload

```sql
' OR '1'='1
```

**Observation**

The application handled the input without allowing unauthorized access.

---

## Cross-Site Scripting (XSS)

### Payload

```html
<script>alert(1)</script>
```

### Payload

```html
<img src=x onerror=alert(1)>
```

**Observation**

The application implemented input validation and encoding mechanisms to reduce the risk of reflected XSS in the tested locations.

---

# 📋 Vulnerabilities Identified

Examples of findings that may appear during the scan include:

- Missing Content Security Policy (CSP)
- Missing X-Frame-Options Header
- Missing X-Content-Type-Options Header
- Cookie Without SameSite Attribute
- Information Disclosure
- Timestamp Disclosure
- Server Information Leakage

> **Note:** The exact findings depend on the version of OWASP Juice Shop and the scan configuration.

---

# 📊 Results

- Successfully scanned the local OWASP Juice Shop application.
- Identified multiple security observations through automated scanning.
- Generated an HTML penetration testing report.
- Performed introductory manual testing using safe payloads.
- Learned how automated scanning complements manual verification.

---

# 📚 Concepts Learned

- Ethical Hacking Fundamentals
- Web Application Penetration Testing
- OWASP Top 10
- Passive Scanning
- Active Scanning
- Spidering
- Security Headers
- HTTP Requests & Responses
- Vulnerability Assessment
- Security Reporting

---

# 📸 Screenshots

Include screenshots of:

- OWASP Juice Shop Homepage
- Automated Scan
- Sites Tree
- Alerts Panel
- Generated HTML Report

---

# 🔐 Ethical Considerations

This project was conducted exclusively against a locally hosted OWASP Juice Shop instance designed for security training. No unauthorized systems or third-party applications were targeted.

---

# 📈 Future Improvements

- Perform authenticated scanning.
- Explore API security testing.
- Integrate OWASP ZAP into a CI/CD pipeline.
- Compare findings with Burp Suite Community Edition.
- Conduct deeper manual verification of identified issues.

---

# 🎓 Learning Outcomes

After completing this project, I gained practical experience in:

- Setting up a vulnerable web application
- Configuring OWASP ZAP
- Performing automated vulnerability scans
- Understanding common web security issues
- Generating professional penetration testing reports
- Following ethical security testing practices

---

# 👨‍💻 Author

**Rohit**

Cybersecurity & Ethical Hacking Internship Project

---

## ⭐ If you found this project useful, consider giving it a Star!