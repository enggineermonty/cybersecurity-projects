# Vulnerability Assessment Using Nessus Essentials

## 📌 Project Overview

This project demonstrates a vulnerability assessment performed using Nessus Essentials. The objective was to identify potential security vulnerabilities in a target system and analyze the associated risks.

---

## 🎯 Objective

* Perform vulnerability scanning using Nessus Essentials.
* Identify security weaknesses in a target system.
* Analyze vulnerability severity levels.
* Generate a vulnerability assessment report.
* Recommend mitigation measures.

---

## 🛠 Tools Used

* Nessus Essentials
* macOS
* Localhost (127.0.0.1)

---

## 🔍 Scan Configuration

| Parameter     | Value              |
| ------------- | ------------------ |
| Scan Type     | Basic Network Scan |
| Scanner       | Local Scanner      |
| Target        | 127.0.0.1          |
| Severity Base | CVSS v3.0          |

---

## 📋 Methodology

### Step 1

Installed Nessus Essentials on macOS.

### Step 2

Activated Nessus using an activation key.

### Step 3

Created a Basic Network Scan.

### Step 4

Configured the target as localhost (127.0.0.1).

### Step 5

Executed the vulnerability scan.

### Step 6

Reviewed identified vulnerabilities and risk levels.

### Step 7

Generated a vulnerability assessment report.

---

## 📊 Results

The vulnerability scan successfully identified multiple informational findings and potential security weaknesses on the target system.

### Severity Categories

* Critical
* High
* Medium
* Low
* Informational

---

## 📚 Skills Learned

* Vulnerability Assessment
* Security Analysis
* CVSS Risk Scoring
* Vulnerability Reporting
* Nessus Configuration
* Cybersecurity Fundamentals

---

## ✅ Conclusion

This project successfully demonstrated the use of Nessus Essentials for vulnerability assessment. Regular vulnerability scanning helps organizations identify security weaknesses and improve their overall security posture.

---

## 👨‍💻 Author

**Sarth Vishal Mokashe**

Cybersecurity & Ethical Hacking Internship
